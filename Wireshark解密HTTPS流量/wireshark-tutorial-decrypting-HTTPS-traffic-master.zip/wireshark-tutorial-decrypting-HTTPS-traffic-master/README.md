# wireshark-tutorial-decrypting-HTTPS-traffic

This Github repository contains a zip archive with a pcap and KeysLog text file for our Wireshark tutorial on decrypting HTTPS traffic.

The password for any of the zip files posted here is: infected
